#include "effects.h"

void distortion(int *L, int *R, int effectStrength){
    //interpret 32 bit data
    //study distortion try to create tanh clipping with varying clipping using effect strength
    int threshold = 0x7FFFFF << effectStrength; //clip at half input set to less for more distortion

    if(*L > threshold){
        *L = threshold;
    }
    
    if(*L < -threshold){
        *L = -threshold;
    }


    *R = *L;
    
}